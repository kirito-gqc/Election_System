/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Acer
 */
@Stateless
public class MyStudentFacade extends AbstractFacade<MyStudent> {

    @PersistenceContext(unitName = "APUElectionSystem-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MyStudentFacade() {
        super(MyStudent.class);
    }
    
    public MyStudent checkName (String name){
        MyStudent found = null;
        Query a = em.createNamedQuery("MyStudent.searchByName");
        a.setParameter("name", name );
        List<MyStudent> data = a.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }
    
    public MyStudent checkTPNum(String TP) {
        MyStudent found = null;
        Query b = em.createNamedQuery("MyStudent.searchByTPNum");
        b.setParameter("TP", TP );
        List<MyStudent> data = b.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    } 
    
    public MyStudent checkEmail(String email) {
        MyStudent found = null;
        Query c = em.createNamedQuery("MyStudent.searchByEmail");
        c.setParameter("email", email );
        List<MyStudent> data = c.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }
}
