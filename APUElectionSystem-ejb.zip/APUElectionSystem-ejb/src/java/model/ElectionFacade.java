/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Acer
 */
@Stateless
public class ElectionFacade extends AbstractFacade<Election> {

    @PersistenceContext(unitName = "APUElectionSystem-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ElectionFacade() {
        super(Election.class);
    }

    public Election checkName (String name){
        Election found = null;
        Query a = em.createNamedQuery("Election.searchByName");
        a.setParameter("name", name );
        List<Election> data = a.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }

}
