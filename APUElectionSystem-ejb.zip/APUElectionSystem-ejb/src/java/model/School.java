/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Acer
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "School.searchByName", query = "SELECT a FROM School a WHERE a.schoolName= :name"),
})
public class School implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Schoolid;
    private String schoolName;
    private String schoolCode;
    @OneToMany
    private ArrayList<MyStudent> student = new ArrayList<MyStudent>();

    public School() {
    }

    public School(String schoolName, String schoolCode) {
        this.schoolName = schoolName;
        this.schoolCode = schoolCode;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getSchoolCode() {
        return schoolCode;
    }

    public void setSchoolCode(String schoolCode) {
        this.schoolCode = schoolCode;
    }

    public Long getSchoolId() {
        return Schoolid;
    }

    public void setSchoolId(Long Schoolid) {
        this.Schoolid = Schoolid;
    }
    
    public ArrayList<MyStudent> getStudent() {
        return student;
    }

    public void setStudent(ArrayList<MyStudent> student) {
        this.student = student;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Schoolid != null ? Schoolid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof School)) {
            return false;
        }
        School other = (School) object;
        if ((this.Schoolid == null && other.Schoolid != null) || (this.Schoolid != null && !this.Schoolid.equals(other.Schoolid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.School[ Schoolid=" + Schoolid + " ]";
    }

    
}
