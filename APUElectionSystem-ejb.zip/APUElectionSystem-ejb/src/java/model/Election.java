/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Acer
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Election.searchByName", query = "SELECT a FROM Election a WHERE a.electName= :name"),
})
public class Election implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Electionid;
    private String electName;
    private String electStart;
    private String electEnd;
    private int SeatNum;
    private String status;
    @OneToMany
    private ArrayList<Seat> electSeat = new ArrayList<Seat>();
    
    @OneToMany
    private ArrayList<School> school = new ArrayList<School>();

    public Election() {
    }

    public Election(String electName, String electStart, String electEnd, int SeatNum, String status) {
        this.electName = electName;
        this.electStart = electStart;
        this.electEnd = electEnd;
        this.SeatNum = SeatNum;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getSeatNum() {
        return SeatNum;
    }

    public void setSeatNum(int SeatNum) {
        this.SeatNum = SeatNum;
    }

    public Long getElectionid() {
        return Electionid;
    }

    public void setElectionid(Long Electionid) {
        this.Electionid = Electionid;
    }

    public String getElectName() {
        return electName;
    }

    public void setElectName(String electName) {
        this.electName = electName;
    }

    public String getElectStart() {
        return electStart;
    }

    public void setElectStart(String electStart) {
        this.electStart = electStart;
    }

    public String getElectEnd() {
        return electEnd;
    }

    public void setElectEnd(String electEnd) {
        this.electEnd = electEnd;
    }
    
    public ArrayList<School> getSchool() {
        return school;
    }

    public void setSchool(ArrayList<School> school) {
        this.school = school;
    }
    
    public ArrayList<Seat> getSeat() {
        return electSeat;
    }

    public void setSeat(ArrayList<Seat> electSeat) {
        this.electSeat = electSeat;
    }



    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Electionid != null ? Electionid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Election)) {
            return false;
        }
        Election other = (Election) object;
        if ((this.Electionid == null && other.Electionid != null) || (this.Electionid != null && !this.Electionid.equals(other.Electionid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Election[ Electionid=" + Electionid + " ]";
    }
    
}
