/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/**
 *
 * @author Acer
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "MyStudent.searchByName", query = "SELECT a FROM MyStudent a WHERE a.name= :name"),
    @NamedQuery(name = "MyStudent.searchByTPNum", query = "SELECT b FROM MyStudent b WHERE b.TPnum= :TP"),
    @NamedQuery(name = "MyStudent.searchByEmail", query = "SELECT c FROM MyStudent c WHERE c.email= :email"),
})
public class MyStudent implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Studentid;
    private String name;
    private String TPnum;
    private String password;
    private char gender;
    private String phoneNum;
    private String email;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    @OneToMany
    private ArrayList<Vote> vote = new ArrayList<Vote>();

    public MyStudent() {
    }

    public MyStudent(String name, String TPnum, String password, char gender, String phoneNum, String email, String status) {
        this.name = name;
        this.TPnum = TPnum;
        this.password = password;
        this.gender = gender;
        this.phoneNum = phoneNum;
        this.email = email;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTPnum() {
        return TPnum;
    }

    public void setTPnum(String TPnum) {
        this.TPnum = TPnum;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getStudentId() {
        return Studentid;
    }

    public void setStudentId(Long Studentid) {
        this.Studentid = Studentid;
    }

    public ArrayList<Vote> getVote() {
        return vote;
    }

    public void setVote(ArrayList<Vote> vote) {
        this.vote = vote;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Studentid != null ? Studentid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MyStudent)) {
            return false;
        }
        MyStudent other = (MyStudent) object;
        if ((this.Studentid == null && other.Studentid != null) || (this.Studentid != null && !this.Studentid.equals(other.Studentid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.MyStudent[ Studentid=" + Studentid + " ]";
    }

    
}
