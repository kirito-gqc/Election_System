/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Acer
 */
@Stateless
public class MyCommitteeFacade extends AbstractFacade<MyCommittee> {

    @PersistenceContext(unitName = "APUElectionSystem-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MyCommitteeFacade() {
        super(MyCommittee.class);
    }
    
    public MyCommittee checkName (String name){
        MyCommittee found = null;
        Query a = em.createNamedQuery("MyCommittee.searchByName");
        a.setParameter("name", name );
        List<MyCommittee> data = a.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }

    public MyCommittee checkTPNum(String TP) {
        MyCommittee found = null;
        Query b = em.createNamedQuery("MyCommittee.searchByTPNum");
        b.setParameter("TP", TP );
        List<MyCommittee> data = b.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }
    
    public MyCommittee checkEmail(String email) {
        MyCommittee found = null;
        Query c = em.createNamedQuery("MyCommittee.searchByEmail");
        c.setParameter("email", email );
        List<MyCommittee> data = c.getResultList();
        if(data.size()>0){
            found = data.get(0);
        }
        return found;
    }
        
    
}
