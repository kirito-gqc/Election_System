/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

/**
 *
 * @author Acer
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "MyCommittee.searchByName", query = "SELECT a FROM MyCommittee a WHERE a.name= :name"),
    @NamedQuery(name = "MyCommittee.searchByTPNum", query = "SELECT b FROM MyCommittee b WHERE b.TPNum= :TP"),
    @NamedQuery(name = "MyCommittee.searchByEmail", query = "SELECT c FROM MyCommittee c WHERE c.email= :email"),
})
public class MyCommittee implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Committeeid;
    private String name;
    private String TPNum;
    private String password;
    private char gender;
    private String email;
    private String position;

    public String getTPNum() {
        return TPNum;
    }

    public void setTPNum(String TPNum) {
        this.TPNum = TPNum;
    }


    public MyCommittee(String name, String TPNum,String password, char gender, String email, String position) {
        this.name = name;
        this.TPNum = TPNum;
        this.password = password;
        this.gender = gender;
        this.email = email;
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
    
    public MyCommittee(){
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getCommitteeId() {
        return Committeeid;
    }

    public void setCommitteeId(Long Committeeid) {
        this.Committeeid = Committeeid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Committeeid != null ? Committeeid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MyCommittee)) {
            return false;
        }
        MyCommittee other = (MyCommittee) object;
        if ((this.Committeeid == null && other.Committeeid != null) || (this.Committeeid != null && !this.Committeeid.equals(other.Committeeid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.MyCommunity[ Committeeid=" + Committeeid + " ]";
    }
    
}
