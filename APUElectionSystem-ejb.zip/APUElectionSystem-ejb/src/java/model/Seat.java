/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author Acer
 */
@Entity
@NamedQueries({
    @NamedQuery(name = "Seat.searchByPosition", query = "SELECT a FROM Seat a WHERE a.positionElec= :position"),
})
public class Seat implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Seatid;
    private String positionElec;
    private String status;
    @OneToOne
    private Winner winner = new Winner();
    
    @OneToMany
    private ArrayList<MyContester> myContester = new ArrayList<MyContester>();

    @OneToMany
    private ArrayList<Vote> Vote = new ArrayList<Vote>();

    public Seat(String positionElec, String status) {
        this.positionElec = positionElec;
        this.status = status;
    }

    public Seat() {
    }

    public String getPositionElec() {
        return positionElec;
    }

    public void setPositionElec(String positionElec) {
        this.positionElec = positionElec;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Winner getWinner() {
        return winner;
    }

    public void setWinner(Winner winner) {
        this.winner = winner;
    }

    public ArrayList<MyContester> getMyContester() {
        return myContester;
    }

    public void setMyContester(ArrayList<MyContester> myContester) {
        this.myContester = myContester;
    }

    public ArrayList<Vote> getVote() {
        return Vote;
    }

    public void setVote(ArrayList<Vote> Vote) {
        this.Vote = Vote;
    }
    
    public Long getSeatId() {
        return Seatid;
    }

    public void setSeatId(Long Seatid) {
        this.Seatid = Seatid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Seatid != null ? Seatid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Seat)) {
            return false;
        }
        Seat other = (Seat) object;
        if ((this.Seatid == null && other.Seatid != null) || (this.Seatid != null && !this.Seatid.equals(other.Seatid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Seat[ Seatid=" + Seatid + " ]";
    }

    
}
