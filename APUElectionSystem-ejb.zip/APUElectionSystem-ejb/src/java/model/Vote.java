/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Acer
 */
@Entity
public class Vote implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Voteid;
    private String selection;

    public Vote() {
    }

    public Vote( String selection) {
        this.selection = selection;
    }

    public String getSelection() {
        return selection;
    }

    public void setSelection(String selection) {
        this.selection = selection;
    }

    public Long getVoteId() {
        return Voteid;
    }

    public void setVoteId(Long Voteid) {
        this.Voteid = Voteid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (Voteid != null ? Voteid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vote)) {
            return false;
        }
        Vote other = (Vote) object;
        if ((this.Voteid == null && other.Voteid != null) || (this.Voteid != null && !this.Voteid.equals(other.Voteid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Vote[ Voteid=" + Voteid + " ]";
    }

    
}
