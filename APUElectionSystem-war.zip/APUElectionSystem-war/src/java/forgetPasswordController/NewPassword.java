/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forgetPasswordController;

import java.util.*;

/**
 *
 * @author Acer
 */
public class NewPassword {
    public static char[] getNewPassowrd()
    {
        int length = 8;
        char[] password = generatePassword(length);
        return password;
    }
  
    // This our Password generating method
    // We have use static here, so that we not to
    // make any object for it
    static char[] generatePassword(int len)
    {
  
        // A strong password has Cap_chars, Lower_chars,
        // numeric value and symbols. So we are using all of
        // them to generate our password
        String Capital_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String Small_chars = "abcdefghijklmnopqrstuvwxyz";
        String numbers = "0123456789";
  
  
        String values = Capital_chars + Small_chars +
                        numbers;
  
        // Using random method
        Random rndm_method = new Random();
  
        char[] password = new char[len];
  
        for (int i = 0; i < len; i++)
        {
            password[i] =
              values.charAt(rndm_method.nextInt(values.length()));
  
        }
        return password;
    }

    
}
