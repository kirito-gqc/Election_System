/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forgetPasswordController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;
import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.MyCommittee;
import model.MyCommitteeFacade;
import model.MyContester;
import model.MyContesterFacade;
import model.MyStudent;
import model.MyStudentFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ForgetPassword", urlPatterns = {"/ForgetPassword"})
public class ForgetPassword extends HttpServlet {
    private String host;
    private String port;
    private String user;
    private String pass;
    
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = context.getInitParameter("host");
        port = context.getInitParameter("port");
        user = context.getInitParameter("user");
        pass = context.getInitParameter("pass");
    }

    @EJB
    private MyStudentFacade myStudentFacade;

    @EJB
    private MyContesterFacade myContesterFacade;

    @EJB
    private MyCommitteeFacade myCommitteeFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email");
        String position = request.getParameter("position");
        String newpassword = null;
        try (PrintWriter out = response.getWriter()) {
            if(position.equalsIgnoreCase("Committee")){
                MyCommittee found = myCommitteeFacade.checkEmail(email);
                if(found!=null){
                        for( int i=0;i<100;i++) {
                            String generatepassword = String.valueOf(NewPassword.getNewPassowrd());
                        if(Pattern.matches("([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*",generatepassword)){
                            newpassword = generatepassword;
                            break;
                            }
                        }
                    found.setPassword(newpassword);
                    myCommitteeFacade.edit(found);
                    String subject = "New "+position+" password generated";
                    String content = "The new password generated is "+newpassword+". Please change to new password after log in with the auto-generated password for security purpose.";
                    
                    try {
                            EmailUtility.sendEmail(host, port, user, pass, email, subject,content);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('The new password generation e-mail was sent successfully');");
                             out.println("</script>");
                            request.getRequestDispatcher("/main/index.jsp").include(request, response);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
        
                else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('The email you typed is currently not available in list! Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("/main/index.jsp").include(request, response);
                    }
            }else if(position.equalsIgnoreCase("Contester")){
                MyContester found = myContesterFacade.checkEmail(email);
                if(found!=null){
                        for( int i=0;i<100;i++) {
                            String generatepassword = String.valueOf(NewPassword.getNewPassowrd());
                        if(Pattern.matches("([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*",generatepassword)){
                            newpassword = generatepassword;
                            break;
                            }
                        }
                    found.setPassword(newpassword);
                    myContesterFacade.edit(found);
                    String subject = "New "+position+" password generated";
                    String content = "The new password generated is "+newpassword+". Please change to new password after log in with the auto-generated password for security purpose.";
                    
                    try {
                            EmailUtility.sendEmail(host, port, user, pass, email, subject,content);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('The new password generation e-mail was sent successfully');");
                             out.println("</script>");
                            request.getRequestDispatcher("/main/index.jsp").include(request, response);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                }else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('The email you typed is currently not available in list! Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("/main/index.jsp").include(request, response);
                    }
            }else if(position.equalsIgnoreCase("Student")){
                MyStudent found = myStudentFacade.checkEmail(email);
                if(found!=null){
                        for( int i=0;i<100;i++) {
                            String generatepassword = String.valueOf(NewPassword.getNewPassowrd());
                        if(Pattern.matches("([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*",generatepassword)){
                            newpassword = generatepassword;
                            break;
                            }
                        }
                    found.setPassword(newpassword);
                    myStudentFacade.edit(found);
                    String subject = "New "+position+" password generated";
                    String content = "The new password generated is "+newpassword+". Please change to new password after log in with the auto-generated password for security purpose.";
                    
                    try {
                            EmailUtility.sendEmail(host, port, user, pass, email, subject,content);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('The new password generation e-mail was sent successfully');");
                             out.println("</script>");
                            request.getRequestDispatcher("/main/index.jsp").include(request, response);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                }else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('The email you typed is currently not available in list! Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("/main/index.jsp").include(request, response);
                    }
            }
        }
    }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
