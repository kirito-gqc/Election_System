/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ElectionFacade;
import model.MyStudent;
import model.Seat;
import model.SeatFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ViewSeat", urlPatterns = {"/ViewSeat"})
public class ViewSeat extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private SeatFacade seatFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         HttpSession s = request.getSession(false);
        MyStudent loginstudent = (MyStudent)s.getAttribute("loginstudent");
        Long electionid = (Long) s.getAttribute("electionid");
        Long studentid = loginstudent.getStudentId();
        String search = "";
       String action = request.getParameter("action");
        try (PrintWriter out = response.getWriter()) {
            if(action==null){
                HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                l.setAttribute("search",search);

                request.getRequestDispatcher("student/viewseat.jsp").include(request, response);
            }else if(action.equalsIgnoreCase("search")){
                 HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                search = request.getParameter("search");
                l.setAttribute("search", search);
                request.getRequestDispatcher("student/viewseat.jsp").include(request, response);
            }else if(action.equalsIgnoreCase("view")){
                Long id = Long.parseLong(request.getParameter("electionid"));
                Long seatid = Long.parseLong(request.getParameter("seatid"));
                try{
                    HttpSession l = request.getSession();
                    l.setAttribute("electionid",id);
                    l.setAttribute("seatid", seatid);
                    Seat seat = seatFacade.findSeatid(seatid);


                l.setAttribute("seat",seat);
               
                request.getRequestDispatcher("student/viewcontester.jsp").include(request, response);
                
                
                }catch(Exception e){
                    request.setAttribute("error", e.getMessage());
                
            }
            }
             
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
