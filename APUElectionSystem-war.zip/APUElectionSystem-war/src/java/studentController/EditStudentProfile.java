/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.MyStudent;
import model.MyStudentFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "EditStudentProfile", urlPatterns = {"/EditStudentProfile"})
public class EditStudentProfile extends HttpServlet {

    @EJB
    private MyStudentFacade myStudentFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession s = request.getSession(false);
        MyStudent editstudent = (MyStudent)s.getAttribute("loginstudent");
        s.getAttribute("studentid");
        
        String name = request.getParameter("name");
        String tpnum = request.getParameter("tpnum");
        char gender = request.getParameter("gender").charAt(0);
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String confirm = request.getParameter("cpassword");

        

        
        
        try (PrintWriter out = response.getWriter()) {
            if(editstudent != null){
                if(Pattern.matches("([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*",password)){
                    if(password.equals(confirm)){
                            editstudent.setName(name);
                            editstudent.setTPnum(tpnum);
                            editstudent.setPassword(password);
                            editstudent.setGender(gender);
                            editstudent.setPhoneNum(phone);
                            editstudent.setEmail(email);
                            myStudentFacade.edit(editstudent);
                        request.getRequestDispatcher("student/studentprofile.jsp").include(request, response);
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Student editted successfully!');");
                        out.println("</script>");

                    }else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Password not matched!Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("student/studentprofile.jsp").include(request, response);
                    }
                }else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('The password requirement is not fulfilled. Please enter password that have at least one alphabet character(a-z/A-Z) and numerical character (0-9) with minimum 5 characters');");
                    out.println("</script>");
                    request.getRequestDispatcher("student/studentprofile.jsp").include(request, response);
                }
            }else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The current name is not exist in this system!Error!');");
                out.println("</script>");
                request.getRequestDispatcher("student/studentprofile.jsp").include(request, response);
            }
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
