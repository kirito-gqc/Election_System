/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.MyContester;
import model.MyContesterFacade;
import model.MyStudent;
import model.Seat;
import model.SeatFacade;
import model.Vote;

/**
 *
 * @author Acer
 */
@WebServlet(name = "SeatContester", urlPatterns = {"/SeatContester"})
public class SeatContester extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private MyContesterFacade myContesterFacade;

    @EJB
    private SeatFacade seatFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession s = request.getSession(false);
        MyStudent loginstudent = (MyStudent)s.getAttribute("loginstudent");
        Long electionid = (Long) s.getAttribute("electionid");
        Long seatid = (Long) s.getAttribute("seatid");
        
        Long studentid = loginstudent.getStudentId();
        String search = "";
       String action = request.getParameter("action");
        try (PrintWriter out = response.getWriter()) {
            if(action==null){
                HttpSession l = request.getSession();
                l.setAttribute("seatid",seatid);
                l.setAttribute("electionid",electionid);
                l.setAttribute("search",search);

                request.getRequestDispatcher("student/viewcontester.jsp").include(request, response);
            }else if(action.equalsIgnoreCase("search")){
                 HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                l.setAttribute("seatid",seatid);
                search = request.getParameter("search");
                l.setAttribute("search", search);
                request.getRequestDispatcher("student/viewcontester.jsp").include(request, response);
            }else if(action.equalsIgnoreCase("view")){
                Long contesterid = Long.parseLong(request.getParameter("contesterid"));
                try{
                    HttpSession l = request.getSession();
                    l.setAttribute("contesterid",contesterid);
                    l.setAttribute("seatid", seatid);
                    Seat seat = seatFacade.findSeatid(seatid);
                MyContester contester = myContesterFacade.findContesterid(contesterid);
                l.setAttribute("seat",seat);
                l.setAttribute("contester",contester);
               
                request.getRequestDispatcher("student/displaycontester.jsp").include(request, response);
                
                
                }catch(Exception e){
                    request.setAttribute("error", e.getMessage());
                
            }
            }else if (action.equalsIgnoreCase("vote")){
                Long contesterid = Long.parseLong(request.getParameter("seatid"));
                        ArrayList<Vote> studentvote = loginstudent.getVote();
                        Election election = electionFacade.findElectionid(electionid);
                        Seat seat = seatFacade.findSeatid(seatid);
                        ArrayList<Vote> seatvote = seat.getVote();
                        studentvote.retainAll(seatvote);
                        if(studentvote.size()<1){

                            try{
                                HttpSession l = request.getSession();
                                l.setAttribute("seatid", seatid);
                                l.setAttribute("electionid", electionid);

                               l.setAttribute("seat",seat);
                               l.setAttribute("election",election);

                            request.getRequestDispatcher("student/studentvote.jsp").include(request, response);
                            }catch(Exception e){
                                request.setAttribute("error", e.getMessage());

                        }
                        }else{
                            HttpSession l = request.getSession();
                            l.setAttribute("electionid",electionid);
                            l.setAttribute("seatid", seatid);


                            l.setAttribute("seat",seat);
               
                            request.getRequestDispatcher("student/viewcontester.jsp").include(request, response);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('You had already voted for this seat. You can only vote for once');");
                            out.println("</script>");
                        }
            }
             
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
