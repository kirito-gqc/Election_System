/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.School;
import model.SchoolFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "AddSchool", urlPatterns = {"/AddSchool"})
public class AddSchool extends HttpServlet {

    @EJB
    private SchoolFacade schoolFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String name = request.getParameter("schoolname");
        String code = request.getParameter("schoolcode");
        
        School found = schoolFacade.checkName(name);
        
        try (PrintWriter out = response.getWriter()) {
            if(found == null){
                        School register = new School(name,code);
                        schoolFacade.create(register);
                        request.getRequestDispatcher("committee/manageschool.jsp").include(request, response);
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('New school added successfully');");
                        out.println("</script>");
            } else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The current school is registered in this system!Please try another name!');");
                out.println("</script>");
                request.getRequestDispatcher("committee/schooladd.jsp").include(request, response);
            }
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
