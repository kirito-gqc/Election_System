/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.School;
import model.Seat;
import model.SeatFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "EditSeat", urlPatterns = {"/EditSeat"})
public class EditSeat extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private SeatFacade seatFacade;


    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         Long electionid = Long.parseLong(request.getParameter("electionid"));
        Long seatid = Long.parseLong(request.getParameter("seatid"));
        Seat editseat = seatFacade.findSeatid(seatid);
        String position = request.getParameter("position");
        try (PrintWriter out = response.getWriter()) {
            if(editseat != null){
                        editseat.setPositionElec(position);
                        seatFacade.edit(editseat);
                         HttpSession l = request.getSession();
                        l.setAttribute("electionid",electionid);
                        Election election = electionFacade.findElectionid(electionid);
                        l.setAttribute("election",election);
                        if((election.getSchool().size())> 1){
                            l.setAttribute("schoolid",0);
                        }else{
                             for(School a:election.getSchool()){
                                l.setAttribute("schoolid",a.getSchoolId());
                            }
                        }


                        request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Seat edited successfully.');");
                        out.println("</script>");

                    
            } else{

               HttpSession l = request.getSession();
                        l.setAttribute("electionid",electionid);
                        Election election = electionFacade.findElectionid(electionid);
                        l.setAttribute("election",election);
                        if((election.getSchool().size())> 1){
                            l.setAttribute("schoolid",0);
                        }else{
                             for(School a:election.getSchool()){
                                l.setAttribute("schoolid",a.getSchoolId());
                            }
                        }


                request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The seat is not existed!Please try againe!');");
                out.println("</script>");
            }
        }catch (Exception e){
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("committee/manageschool.jsp").include(request, response);
        }
                    
//            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
