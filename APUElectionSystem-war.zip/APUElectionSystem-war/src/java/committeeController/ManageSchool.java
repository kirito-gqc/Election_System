/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.MyStudent;
import model.MyStudentFacade;
import model.School;
import model.SchoolFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ManageSchool", urlPatterns = {"/ManageSchool"})
public class ManageSchool extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private MyStudentFacade myStudentFacade;

    @EJB
    private SchoolFacade schoolFacade;
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        List<Election> election = electionFacade.findAll();
        ArrayList<Election> list = new ArrayList<Election>();
        list.addAll(election);
        

        
        try (PrintWriter out = response.getWriter()) {
            
            if(action.equalsIgnoreCase("delete")){
            

                    try{

                        Long id = Long.parseLong(request.getParameter("id"));
                        School school = schoolFacade.findSchoolid(id);
                        if(school.getStudent().size()<1){
                         for(MyStudent a:school.getStudent()){
                            school.getStudent().remove(a);
                            schoolFacade.edit(school);
                            myStudentFacade.remove(a);
                         }
                         schoolFacade.remove(school);
                         request.getRequestDispatcher("committee/manageschool.jsp").include(request, response);
                        }else{
                            request.getRequestDispatcher("committee/manageschool.jsp").include(request, response);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('There are students available in this school. Please confirm and delete them before delete school');");
                            out.println("</script>");
                            
                                 
                                 }

                        
                        


                        
                    }catch(Exception e){
                        request.setAttribute("error", e.getMessage());
                    }
            }else if(action.equalsIgnoreCase("edit")){
                Long id = Long.parseLong(request.getParameter("id"));
                request.setAttribute("school",schoolFacade.findSchoolid(id));
                 HttpSession l = request.getSession();
                l.setAttribute("schoolid",id);

                request.getRequestDispatcher("committee/schooledit.jsp").include(request, response);

            }else if (action.equalsIgnoreCase("view")){
                Long id = Long.parseLong(request.getParameter("id"));
                request.setAttribute("school",schoolFacade.findSchoolid(id));


                request.getRequestDispatcher("committee/viewschool.jsp").include(request, response);
            }
               
            }
            }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
