/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.MyContester;
import model.MyContesterFacade;
import model.School;
import model.Seat;
import model.SeatFacade;
import model.Winner;
import model.WinnerFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "AddSeat", urlPatterns = {"/AddSeat"})
public class AddSeat extends HttpServlet {

    @EJB
    private MyContesterFacade myContesterFacade;

    @EJB
    private WinnerFacade winnerFacade;

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private SeatFacade seatFacade;
    
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Long id = Long.parseLong(request.getParameter("id"));
        String position = request.getParameter("position");
        String status = "Pending";
        String winner = "Pending";
        Seat found = seatFacade.checkName(position);
        Election election = electionFacade.findElectionid(id);
        int seatnum = election.getSeatNum();
        int size = election.getSeat().size() +1;
        
        try (PrintWriter out = response.getWriter()) {
            if(found == null){
                if (seatnum>=size){
                    String name = "Annonymous";
                    String tpnum = "Annonymous";
                    String password = "Annonymous";
                    char gender= "X".charAt(0);
                    String phone = "Annonymous";
                    String email= "Annonymous";
                    String URL= "Annonymous";
                    String astatus= "Annonymous";

                    MyContester annonymous = new MyContester(name,tpnum,password,gender,phone,email,URL,astatus);
                    myContesterFacade.create(annonymous);

                    Winner a = new Winner();
                    a.setContester(annonymous);
                    winnerFacade.create(a);


                    Seat register = new Seat(position,status);
                    register.setWinner(a);

                    seatFacade.create(register);
                    election.getSeat().add(register);
                    electionFacade.edit(election);
                    HttpSession l = request.getSession();
                        l.setAttribute("electionid",id);
                        l.setAttribute("election",election);
                        if((election.getSchool().size())> 1){
                            l.setAttribute("schoolid",0);
                        }else{
                            for(School b:election.getSchool()){
                                l.setAttribute("schoolid",b.getSchoolId());
                            }
                        }


                        request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('New seat added successfully');");
                    out.println("</script>");
                }else{
                   out.println("<script type=\"text/javascript\">");
                    out.println("alert('The current seat number is exist limit!Please change the seat number in election if you want to add more seat!');");
                    out.println("</script>");
                    request.getRequestDispatcher("committee/seatadd.jsp").include(request, response); 
                }
            } else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The current seat is registered in this system!Please try another name!');");
                out.println("</script>");
                request.getRequestDispatcher("committee/seatadd.jsp").include(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
