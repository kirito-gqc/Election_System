/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.School;
import model.SchoolFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "EditElection", urlPatterns = {"/EditElection"})
public class EditElection extends HttpServlet {

    @EJB
    private SchoolFacade schoolFacade;

    @EJB
    private ElectionFacade electionFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        HttpSession l = request.getSession(false);
//        Object id = l.getAttribute("electionid"); 
        Long electionid = Long.parseLong(request.getParameter("electionid"));
        Long schoolid = Long.parseLong(request.getParameter("schoolid"));
        Election editelection = electionFacade.findElectionid(electionid);
        School editschool = schoolFacade.findSchoolid(schoolid);
        String name = request.getParameter("electname");
        String start = request.getParameter("electstart");
        String end = request.getParameter("electend");
        Integer seatnum = Integer.parseInt(request.getParameter("seatnum"));
        Long newschool = Long.parseLong(request.getParameter("school"));
        int size = editelection.getSchool().size();
        

        
        
        try (PrintWriter out = response.getWriter()) {
            if(editelection != null){
                editelection.setElectName(name);
                        editelection.setElectStart(start);
                        editelection.setElectEnd(end);
                        editelection.setSeatNum(seatnum);
                        electionFacade.edit(editelection);
                if (size == 1){
                   if(newschool==0){
                        List<School> involved = schoolFacade.findAll();
                        ArrayList<School> list = new ArrayList<School>();
                        list.addAll(involved);
                        editelection.setSchool(list);
                        electionFacade.edit(editelection);
                   }else{
                    School school = schoolFacade.findSchoolid(newschool);
                    editelection.getSchool().set(0,school);
                    electionFacade.edit(editelection);
                    }
                }else{
                    if(newschool!=0){
                        ArrayList<School> list = new ArrayList<School>();
                        School school = schoolFacade.findSchoolid(newschool);
                        list.add(school);
                        editelection.setSchool(list);
                        electionFacade.edit(editelection);
                    }
                }
                    
                        


                        request.getRequestDispatcher("committee/manageelection.jsp").include(request,response);
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('School edited successfully.');");
                        out.println("</script>");

                    
            } else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The election is not existed!Please try againe!');");
                out.println("</script>");
               request.getRequestDispatcher("committee/manageelection.jsp").include(request,response);
            }
        }catch (Exception e){
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("committee/manageelection.jsp").include(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
