/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.MyContester;
import model.MyContesterFacade;
import model.School;
import model.Seat;
import model.SeatFacade;
import model.Winner;
import model.WinnerFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ManageSeat", urlPatterns = {"/ManageSeat"})
public class ManageSeat extends HttpServlet {

    @EJB
    private MyContesterFacade myContesterFacade;

    @EJB
    private WinnerFacade winnerFacade;

    @EJB
    private SeatFacade seatFacade;

    @EJB
    private ElectionFacade electionFacade;
    
    

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");

        
        try (PrintWriter out = response.getWriter()) {
            if(action.equalsIgnoreCase("add")){
                 try{
                    Long id = Long.parseLong(request.getParameter("electionid"));
                    request.setAttribute("electionid",id);

                    
                    request.getRequestDispatcher("committee/seatadd.jsp").include(request, response);
                }catch(Exception e){
                    request.setAttribute("error", e.getMessage());
                }
            }
            else if(action.equalsIgnoreCase("delete")){
                Long seatid = Long.parseLong(request.getParameter("seatid"));
                Long electionid = Long.parseLong(request.getParameter("electionid"));
                Election election = electionFacade.findElectionid(electionid);
                Seat seat = seatFacade.findSeatid(seatid);
                if(seat.getMyContester().size()<1){
                    Winner winner = seat.getWinner();
                    MyContester anonymous = winner.getContester();
                    election.getSeat().remove(seat);
                    electionFacade.edit(election);
                    seatFacade.remove(seat);
                    winnerFacade.remove(winner);
                    myContesterFacade.remove(anonymous);
                     HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                l.setAttribute("election",election);
                if((election.getSchool().size())> 1){
                    l.setAttribute("schoolid",0);
                }else{
                     for(School a:election.getSchool()){
                        l.setAttribute("schoolid",a.getSchoolId());
                    }
                }


                request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
//                    request.getRequestDispatcher("ManageElection?action=view&electionid="+electionid).include(request, response);
                }else{
                    
                            HttpSession l = request.getSession();
                       l.setAttribute("electionid",electionid);
                       l.setAttribute("election",election);
                       if((election.getSchool().size())> 1){
                           l.setAttribute("schoolid",0);
                       }else{
                            for(School a:election.getSchool()){
                               l.setAttribute("schoolid",a.getSchoolId());
                           }
                       }
                    request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('There are contesters available in this seat. Please confirm and delete them before delete seat');");
                    out.println("</script>");
                    
                }

            }else if(action.equalsIgnoreCase("edit")){
                Long seatid = Long.parseLong(request.getParameter("seatid"));
                Long electionid = Long.parseLong(request.getParameter("electionid"));
                Election election = electionFacade.findElectionid(electionid);
                Seat seat = seatFacade.findSeatid(seatid);
                HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                l.setAttribute("seatid",seatid);
                l.setAttribute("election",election);
                l.setAttribute("seat",seat);

                request.getRequestDispatcher("committee/seatedit.jsp").include(request, response);

            }else if (action.equalsIgnoreCase("view")){
                Long id = Long.parseLong(request.getParameter("seatid"));
                Long electionid = Long.parseLong(request.getParameter("electionid"));
                HttpSession l = request.getSession();
                l.setAttribute("electionid",electionid);
                l.setAttribute("seatid",id);
                Seat seat = seatFacade.findSeatid(id);
                l.setAttribute("seat",seat);
               
                request.getRequestDispatcher("committee/viewcontester.jsp").include(request, response);
            }else if (action.equalsIgnoreCase("complete")){
                Long electionid = Long.parseLong(request.getParameter("electionid"));
                Election election = electionFacade.findElectionid(electionid);
                ArrayList<Seat> seat = election.getSeat();
                String imcomplete = null;
                for (Seat a: seat){
                    String seatstatus = a.getStatus();
                    if(!"Completed".equalsIgnoreCase(seatstatus)){
                        imcomplete = "incomplete";
                        }
                }
                if(imcomplete != null){
                    HttpSession l = request.getSession();
                    l.setAttribute("electionid",electionid);
                    l.setAttribute("election",election);
                    if((election.getSchool().size())> 1){
                        l.setAttribute("schoolid",0);
                     }else{
                        for(School b:election.getSchool()){
                            l.setAttribute("schoolid",b.getSchoolId());
                        }
                    }
                    request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('There are seats that are still on going. Please confirm the winner before end the election!');");
                            out.println("</script>");    
                
                    }
                else{
                     election.setStatus("Completed");
                     electionFacade.edit(election);
                     request.getRequestDispatcher("committee/manageelection.jsp").include(request, response);
                     out.println("<script type=\"text/javascript\">");
                            out.println("alert('The election is completed!');");
                            out.println("</script>");    
                }
            
            }
               
            }
            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
