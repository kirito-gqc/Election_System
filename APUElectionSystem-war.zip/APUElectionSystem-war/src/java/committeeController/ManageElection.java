/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.School;
import model.SchoolFacade;


/**
 *
 * @author Acer
 */
@WebServlet(name = "ManageElection", urlPatterns = {"/ManageElection"})
public class ManageElection extends HttpServlet {


    @EJB
    private ElectionFacade electionFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");

        
        try (PrintWriter out = response.getWriter()) {
            
            if(action.equalsIgnoreCase("delete")){

                try{
                    Long id = Long.parseLong(request.getParameter("electionid"));
                    Election election = electionFacade.findElectionid(id);
                    if(election.getSeat().size()<1){
                        electionFacade.remove(election);


                        request.getRequestDispatcher("committee/manageelection.jsp").include(request, response);
                    }else{
                        request.getRequestDispatcher("committee/manageelection.jsp").include(request, response);
                            out.println("<script type=\"text/javascript\">");
                            out.println("alert('There are seats available in this election. Please confirm and delete them before delete election');");
                            out.println("</script>");
                    }

                }catch(Exception e){
                    request.setAttribute("error", e.getMessage());
                }
            }else if(action.equalsIgnoreCase("edit")){
                Long id = Long.parseLong(request.getParameter("electionid"));
                HttpSession l = request.getSession();
                Election election = electionFacade.findElectionid(id);
                l.setAttribute("electionid",id);
                l.setAttribute("election",election);
                if((election.getSchool().size())> 1){
                    l.setAttribute("schoolid",0);
                }else{
                     for(School a:election.getSchool()){
                        l.setAttribute("schoolid",a.getSchoolId());
                    }
                }

                request.getRequestDispatcher("committee/electionedit.jsp").include(request, response);

            }else if (action.equalsIgnoreCase("view")){
                Long id = Long.parseLong(request.getParameter("electionid"));
                try{
                HttpSession l = request.getSession();
                l.setAttribute("electionid",id);
                Election election = electionFacade.findElectionid(id);
                l.setAttribute("election",election);
                if((election.getSchool().size())> 1){
                    l.setAttribute("schoolid",0);
                }else{
                     for(School a:election.getSchool()){
                        l.setAttribute("schoolid",a.getSchoolId());
                    }
                }


                request.getRequestDispatcher("committee/manageseat.jsp").include(request, response);
                
                
                }catch(Exception e){
                    request.setAttribute("error", e.getMessage());
                
            }
            }
               
            }
            }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
