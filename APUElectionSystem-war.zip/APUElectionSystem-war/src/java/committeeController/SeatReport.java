/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package committeeController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.Seat;
import model.SeatFacade;
import model.Vote;
import model.WinnerFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "SeatReport", urlPatterns = {"/SeatReport"})
public class SeatReport extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private SeatFacade seatFacade;

    @EJB
    private WinnerFacade winnerFacade;

    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession l = request.getSession(false);
        Long electionid = (Long) l.getAttribute("electionid");
        Election election = electionFacade.findElectionid(electionid);
        String action = request.getParameter("action");
        int total = Integer.parseInt(request.getParameter("total"));
        try (PrintWriter out = response.getWriter()) {
           if(action.equalsIgnoreCase("winner")){
               Long seatid = Long.parseLong(request.getParameter("seatid"));
               Seat seat = seatFacade.findSeatid(seatid);
               int voted = seat.getVote().size();
               if ((total/2)<voted){
                   ArrayList<Vote> count = seat.getVote();
                   ArrayList<String> list = new ArrayList<String>();
                   for (Vote a: count){
                       String selection = a.getSelection();
                       list.add(selection);
                   }
                   // hashmap to store the frequency of element
                    Map<String, Integer> hm = new HashMap<String, Integer>();

                    for (String i : list) {
                        Integer j = hm.get(i);
                        hm.put(i, (j == null) ? 1 : j + 1);
                    }
                    int maxValueInMap=(Collections.max(hm.values()));
                    ArrayList<String> potential = new ArrayList<String>();
                    // displaying the occurrence of elements in the arraylist
                    for (Map.Entry<String, Integer> val : hm.entrySet()) {
                        if (val.getValue()==maxValueInMap) {
                            potential.add(val.getKey());     // Print the key with max value
                        }
                    }
                    HttpSession s = request.getSession();
                    s.setAttribute("electionid",electionid);
                    s.setAttribute("election",election);
                    s.setAttribute("seatid", seatid);
                    s.setAttribute("seat",seat);
                    s.setAttribute("potential",potential);
                    request.getRequestDispatcher("committee/winnerapprove.jsp").include(request, response);
               }else{
                    HttpSession s = request.getSession();
                    s.setAttribute("electionid",electionid);
                    s.setAttribute("seatid", seatid);
                    request.getRequestDispatcher("committee/seatreport.jsp").include(request, response);
                    out.println("<script type=\"text/javascript\">");
                        out.println("alert('You cannot decide the winner since the voting rate is not even exists half');");
                        out.println("</script>");
               }
           }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
