/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contesterController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.MyContester;
import model.MyContesterFacade;
import model.Seat;
import model.SeatFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ContesterRegister", urlPatterns = {"/ContesterRegister"})
public class ContesterRegister extends HttpServlet {

    @EJB
    private SeatFacade seatFacade;

    @EJB
    private MyContesterFacade myContesterFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String name = request.getParameter("name");
        String tpnum = request.getParameter("tpnum");
        char gender = request.getParameter("gender").charAt(0);
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String confirm = request.getParameter("cpassword");
        String url = request.getParameter("url");
        Long seatid = Long.parseLong(request.getParameter("seat"));
        Seat seat = seatFacade.findSchoolid(seatid);
        MyContester found = myContesterFacade.checkName(name);
        
        try (PrintWriter out = response.getWriter()) {
            if(found == null){
                if(Pattern.matches("([A-Za-z]+[0-9]|[0-9]+[A-Za-z])[A-Za-z0-9]*",password)){
                    if(password.equals(confirm)){
                        String status = "Pending";
                        MyContester register = new MyContester(name,tpnum,password, gender,phone,email,url,status);
                        myContesterFacade.create(register);
                        
                        seat.getMyContester().add(register);
                        seatFacade.edit(seat);

                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Registration successfully. Please proceed to login!');");
                        out.println("</script>");
                        request.getRequestDispatcher("contester/contesterlogin.jsp").include(request, response);

                    }else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Password not matched!Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("contester/contesterregister.jsp").include(request, response);
                    }
                }else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('The password requirement is not fulfilled. Please enter password that have at least one alphabet character(a-z/A-Z) and numerical character (0-9) with minimum 5 characters');");
                    out.println("</script>");
                    request.getRequestDispatcher("contester/contesterregister.jsp").include(request, response);
                }
            } else{
                out.println("<script type=\"text/javascript\">");
                out.println("alert('The current name is registered in this system!Please try another name!');");
                out.println("</script>");
                request.getRequestDispatcher("contester/contesterregister.jsp").include(request, response);
            }
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
