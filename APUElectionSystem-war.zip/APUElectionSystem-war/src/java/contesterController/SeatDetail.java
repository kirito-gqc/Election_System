/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contesterController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Election;
import model.ElectionFacade;
import model.MyContester;
import model.MyContesterFacade;
import model.Seat;
import model.SeatFacade;

/**
 *
 * @author Acer
 */
@WebServlet(name = "SeatDetail", urlPatterns = {"/SeatDetail"})
public class SeatDetail extends HttpServlet {

    @EJB
    private ElectionFacade electionFacade;

    @EJB
    private MyContesterFacade myContesterFacade;

    @EJB
    private SeatFacade seatFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
         HttpSession s = request.getSession(false);
        MyContester logincontester = (MyContester)s.getAttribute("logincontester");
        
        Long contesterid = (Long) s.getAttribute("contesterid");
        Seat seatcontested = null;

        String action = request.getParameter("action");
        try (PrintWriter out = response.getWriter()) {
            if(action==null){
                List<Seat> seat = seatFacade.findAll();
                for (Seat a: seat){
                    ArrayList<MyContester> involved = a.getMyContester();
                    if(involved.contains(logincontester)){
                        seatcontested = a;
                    }

                    }
                Long seatid = seatcontested.getSeatId();
                String seatstatus = seatcontested.getStatus();
                String seatname = seatcontested.getPositionElec();
                HttpSession l = request.getSession();
                l.setAttribute("seatid",seatid);
                l.setAttribute("seatstatus",seatstatus);
                l.setAttribute("position", seatname);
                request.getRequestDispatcher("contester/seatdetail.jsp").include(request, response);


            }else if(action.equalsIgnoreCase("view")){
                Long seatid = Long.parseLong(request.getParameter("seatid"));
                Long id = Long.parseLong(request.getParameter("contesterid"));
                HttpSession l = request.getSession();
                l.setAttribute("seatid",seatid);
                l.setAttribute("contesterid",id);
                Seat seat = seatFacade.findSeatid(seatid);
                s.setAttribute("seat",seat);
                s.setAttribute("contester",logincontester);
                request.getRequestDispatcher("contester/displaycontester.jsp").include(request, response);
            }else if(action.equalsIgnoreCase("report")){
                    Long id = Long.parseLong(request.getParameter("seatid"));
                    Seat seat = seatFacade.findSeatid(id);
                    Election electioncontested = null;
                    List<Election> election = electionFacade.findAll();
                    for (Election a: election){
                        ArrayList<Seat> seatinvolved = a.getSeat();
                    if(seatinvolved.contains(seat)){
                        electioncontested = a;
                    }

                    }
                    Long electionid = electioncontested.getElectionid();
                    HttpSession l = request.getSession();
                    s.setAttribute("seat",seat);
                    s.setAttribute("seatid", id);
                    s.setAttribute("electionid", electionid);
                    request.getRequestDispatcher("contester/seatreport.jsp").include(request, response);
                    
                }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
