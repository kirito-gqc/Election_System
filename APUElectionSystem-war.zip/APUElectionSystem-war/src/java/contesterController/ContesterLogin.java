/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contesterController;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.MyContesterFacade;
import model.MyContester;

/**
 *
 * @author Acer
 */
@WebServlet(name = "ContesterLogin", urlPatterns = {"/ContesterLogin"})
public class ContesterLogin extends HttpServlet {

    @EJB
    private MyContesterFacade myContesterFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String TP = request.getParameter("username");
        String password = request.getParameter("password");
        MyContester found = myContesterFacade.checkTPNum(TP);
//        
        
        try (PrintWriter out = response.getWriter()) {
            if(found == null){
                out.println("<script type=\"text/javascript\">");
                out.println("alert('You are not registered! Please try again');");
                out.println("</script>");
                request.getRequestDispatcher("contester/contesterlogin.jsp").include(request, response);
            }else{ 
                if(found.getStatus().equals("Approved")){
                    if(found.getPassword().equals(password)){
                        HttpSession s = request.getSession();
                        s.setAttribute("logincontester", found);
                        String user = found.getName();
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Welcome to APU E-Voting system!');");
                        out.println("</script>");
                        request.getRequestDispatcher("contester/contesterindex.jsp").include(request, response);
    //                    out.println("<html><body><script>alert('Welcome '+TP+', Please reenter the username and password!');</script></body></html>");
                    } else{
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('You typed in the wrong Password!Please try again');");
                        out.println("</script>");
                        request.getRequestDispatcher("contester/contesterlogin.jsp").include(request, response);
    //                    out.println("<html><body><script>alert('Sorry '+TP+', wrong password!');</script></body></html>");
                    }
                }else{
                    out.println("<script type=\"text/javascript\">");
                out.println("alert('You are not approved yet! Please wait for the committee to approve your registration');");
                out.println("</script>");
                request.getRequestDispatcher("contester/contesterlogin.jsp").include(request, response);
                }
                
            }            
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
